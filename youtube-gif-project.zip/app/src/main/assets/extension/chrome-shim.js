// Bridge Shim untuk YouTube GIF APK by dodosadventure
(() => {
  if (window.__GCFY_SHIM_INITIALIZED__) return;
  window.__GCFY_SHIM_INITIALIZED__ = true;

  const pendingFetches = new Map();
  let fetchSeq = 0;

  window.__gcfyOnNativeFetchResult = function(reqId, ok, status, finalUrl, bodyText, errorMsg) {
    const p = pendingFetches.get(reqId);
    if (!p) return;
    pendingFetches.delete(reqId);
    if (errorMsg) {
      p.reject(new TypeError(errorMsg));
      return;
    }
    p.resolve({
      ok: !!ok,
      status: Number(status) || 200,
      url: finalUrl || p.url,
      text: async () => bodyText || '',
      json: async () => JSON.parse(bodyText || '{}')
    });
  };

  window.__gcfyNativeFetch = function(url, init) {
    return new Promise((resolve, reject) => {
      if (!window.AndroidGifBridge || !window.AndroidGifBridge.nativeFetchAsync) {
        fetch(url, init).then(resolve, reject);
        return;
      }
      const reqId = 'req_' + (++fetchSeq) + '_' + Date.now();
      pendingFetches.set(reqId, { resolve, reject, url: String(url) });
      try {
        window.AndroidGifBridge.nativeFetchAsync(reqId, String(url));
      } catch (e) {
        pendingFetches.delete(reqId);
        reject(new TypeError(String(e)));
      }
    });
  };

  const msgListeners = [];
  const storageListeners = new Set();

  window.chrome = window.chrome || {};
  window.chrome.permissions = {
    contains: async () => true
  };
  window.chrome.tabs = {
    query: async () => []
  };
  window.chrome.scripting = {
    executeScript: async () => {},
    insertCSS: async () => {}
  };
  window.chrome.runtime = {
    id: 'desktop-gifs@dodosadventure',
    getManifest: () => ({ version: '0.1.8' }),
    onInstalled: {
      addListener: () => {}
    },
    onMessage: {
      addListener: (fn) => {
        if (typeof fn === 'function') msgListeners.push(fn);
      }
    },
    sendMessage: (msg) => new Promise((resolve) => {
      let responded = false;
      const sendResponse = (reply) => {
        if (responded) return;
        responded = true;
        resolve(reply);
      };
      for (const fn of msgListeners) {
        try {
          fn(msg, { id: 'desktop-gifs@dodosadventure' }, sendResponse);
        } catch (e) {
          sendResponse({ ok: false, error: String(e) });
        }
      }
      if (!msgListeners.length) {
        sendResponse({ ok: false, error: 'Background bridge belum siap, silakan refresh.' });
      }
    })
  };

  window.chrome.storage = {
    onChanged: {
      addListener: (fn) => storageListeners.add(fn),
      removeListener: (fn) => storageListeners.delete(fn)
    },
    local: {
      get: async (key) => {
        try {
          const raw = window.AndroidGifBridge ? window.AndroidGifBridge.storageGet(String(key || '')) : '{}';
          return JSON.parse(raw || '{}');
        } catch (e) {
          return {};
        }
      },
      set: async (items) => {
        if (!items || typeof items !== 'object') return;
        const changes = {};
        for (const k of Object.keys(items)) {
          changes[k] = { newValue: items[k] };
        }
        if (window.AndroidGifBridge) {
          window.AndroidGifBridge.storageSet(JSON.stringify(items));
        }
        for (const fn of storageListeners) {
          try { fn(changes, 'local'); } catch (e) {}
        }
      },
      remove: async (key) => {
        if (window.AndroidGifBridge) {
          window.AndroidGifBridge.storageRemove(String(key));
        }
      }
    }
  };
})();
