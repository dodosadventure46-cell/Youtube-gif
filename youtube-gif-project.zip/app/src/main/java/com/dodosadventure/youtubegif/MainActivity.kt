package com.dodosadventure.youtubegif

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var rootLayout: FrameLayout
    private lateinit var webView: WebView
    private lateinit var fullscreenContainer: FrameLayout
    private lateinit var quickToolbar: LinearLayout
    private lateinit var fabToggle: Button
    private lateinit var prefs: SharedPreferences

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var currentZoomScale: Int = 95 // Default smart zoom untuk layar HP
    private var toolbarExpanded: Boolean = false

    private val networkExecutor = Executors.newCachedThreadPool()

    // User-Agent Desktop agar komponen komentar ytd-commentbox & tombol GIF selalu aktif
    private val desktopUserAgent =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

    // User-Agent Mobile Chrome murni (tanpa token wv) khusus saat melewati halaman Login Google agar aman dari blokir
    private val googleAuthUserAgent =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"

    private val cachedScripts = mutableMapOf<String, String>()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences("dodosadventure_yt_gif_prefs", Context.MODE_PRIVATE)
        currentZoomScale = prefs.getInt("zoom_scale", 95)

        rootLayout = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#0F0F0F"))
        }

        webView = WebView(this)
        fullscreenContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }

        rootLayout.addView(
            webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        rootLayout.addView(
            fullscreenContainer,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        setupFloatingToolbar()
        setContentView(rootLayout)

        setupWebView()
        setupBackNavigation()

        webView.loadUrl("https://www.youtube.com/?app=desktop&persist_app=1")
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()

    private fun createPillButton(label: String, bgColor: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(Color.parseColor(bgColor))
                setStroke(dp(1), Color.parseColor("#44FFFFFF"))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun setupFloatingToolbar() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        quickToolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(20).toFloat()
                setColor(Color.parseColor("#DD181818"))
                setStroke(dp(1), Color.parseColor("#55FFFFFF"))
            }
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }

        val btnZoomOut = createPillButton("🔍-", "#282828") {
            adjustZoom(-10)
        }
        val btnZoomIn = createPillButton("🔍+", "#282828") {
            adjustZoom(10)
        }
        val btnComments = createPillButton("💬 Komentar", "#065FD4") {
            scrollToComments()
        }
        val btnLogin = createPillButton("🔑 Login", "#282828") {
            openGoogleLogin()
        }
        val btnRefresh = createPillButton("🔄", "#282828") {
            webView.reload()
            Toast.makeText(this, "Memuat ulang & menyuntikkan ekstensi GIF...", Toast.LENGTH_SHORT).show()
        }

        val marginParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            marginEnd = dp(4)
        }

        quickToolbar.addView(btnZoomOut, marginParams)
        quickToolbar.addView(btnZoomIn, marginParams)
        quickToolbar.addView(btnComments, marginParams)
        quickToolbar.addView(btnLogin, marginParams)
        quickToolbar.addView(btnRefresh, marginParams)

        fabToggle = createPillButton("⚡ GIF", "#CCFF0033") {
            toolbarExpanded = !toolbarExpanded
            quickToolbar.visibility = if (toolbarExpanded) View.VISIBLE else View.GONE
            fabToggle.text = if (toolbarExpanded) "✖" else "⚡ GIF"
        }

        container.addView(quickToolbar)
        container.addView(fabToggle)

        val layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            bottomMargin = dp(18)
            marginEnd = dp(12)
        }

        rootLayout.addView(container, layoutParams)
    }

    private fun adjustZoom(delta: Int) {
        currentZoomScale = (currentZoomScale + delta).coerceIn(50, 180)
        prefs.edit().putInt("zoom_scale", currentZoomScale).apply()
        applySmartDesktopViewport()
        Toast.makeText(this, "Skala Tampilan HP: $currentZoomScale%", Toast.LENGTH_SHORT).show()
    }

    private fun scrollToComments() {
        val js = """
            (() => {
                const comments = document.querySelector('#comments, ytd-comments, ytd-item-section-renderer#sections');
                if (comments) {
                    comments.scrollIntoView({ behavior: 'smooth', block: 'start' });
                } else {
                    window.scrollBy({ top: 600, behavior: 'smooth' });
                }
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    private fun openGoogleLogin() {
        webView.settings.userAgentString = googleAuthUserAgent
        webView.loadUrl("https://accounts.google.com/ServiceLogin?service=youtube&continue=https://www.youtube.com/?app=desktop%26persist_app=1")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            textZoom = currentZoomScale
            userAgentString = desktopUserAgent
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        webView.addJavascriptInterface(AndroidGifBridge(), "AndroidGifBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url ?: return false
                val host = uri.host?.lowercase() ?: ""

                // Gunakan User-Agent Mobile Chrome saat masuk ke halaman autentikasi Google agar login lancar
                if (host.contains("accounts.google.") || host.contains("myaccount.google.")) {
                    view.settings.userAgentString = googleAuthUserAgent
                    return false
                }

                // Pastikan semua link m.youtube.com atau youtu.be diarahkan ke www.youtube.com mode desktop
                if (host == "m.youtube.com") {
                    view.settings.userAgentString = desktopUserAgent
                    val desktopUri = uri.buildUpon()
                        .authority("www.youtube.com")
                        .appendQueryParameter("app", "desktop")
                        .appendQueryParameter("persist_app", "1")
                        .build()
                    view.loadUrl(desktopUri.toString())
                    return true
                }

                if (host.contains("youtube.com") || host.contains("youtu.be")) {
                    view.settings.userAgentString = desktopUserAgent
                    return false
                }

                return false
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (url != null && url.contains("youtube.com")) {
                    injectDesktopGifsExtension(view)
                }
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                super.onPageCommitVisible(view, url)
                if (url != null && url.contains("youtube.com")) {
                    applySmartDesktopViewport()
                    injectDesktopGifsExtension(view)
                }
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                CookieManager.getInstance().flush()
                if (url != null && url.contains("youtube.com")) {
                    applySmartDesktopViewport()
                    injectDesktopGifsExtension(view)
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                fullscreenContainer.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                fullscreenContainer.visibility = View.VISIBLE
                webView.visibility = View.GONE
                window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }

            override fun onHideCustomView() {
                val view = customView ?: return
                fullscreenContainer.removeView(view)
                fullscreenContainer.visibility = View.GONE
                webView.visibility = View.VISIBLE
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
    }

    private fun applySmartDesktopViewport() {
        webView.settings.textZoom = currentZoomScale
        // Atur viewport desktop agar ter-zoom rapi dan pas di layar HP
        val scaleFactor = (currentZoomScale / 100.0 * 0.48).coerceIn(0.25, 1.2)
        val viewportJs = """
            (() => {
                let meta = document.querySelector('meta[name="viewport"]');
                if (!meta) {
                    meta = document.createElement('meta');
                    meta.name = 'viewport';
                    document.head && document.head.appendChild(meta);
                }
                if (meta) {
                    meta.content = 'width=980, initial-scale=${"%.2f".format( java.util.Locale.US, scaleFactor )}, minimum-scale=0.25, maximum-scale=3.0, user-scalable=yes';
                }
            })();
        """.trimIndent()
        webView.evaluateJavascript(viewportJs, null)
    }

    private fun readAssetScript(fileName: String): String {
        return cachedScripts.getOrPut(fileName) {
            assets.open("extension/$fileName").bufferedReader().use { it.readText() }
        }
    }

    private fun injectDesktopGifsExtension(view: WebView) {
        val shimJs = readAssetScript("chrome-shim.js")
        val swJs = readAssetScript("sw.js")
        val mainJs = readAssetScript("main.js")
        val contentCss = readAssetScript("content.css")
        val contentJs = readAssetScript("content.js")

        val cssEscaped = JSONObject.quote(contentCss)
        val injectCssJs = """
            (() => {
                if (!document.getElementById('gcfy-injected-style') && document.head) {
                    const style = document.createElement('style');
                    style.id = 'gcfy-injected-style';
                    style.textContent = $cssEscaped;
                    document.head.appendChild(style);
                }
            })();
        """.trimIndent()

        view.evaluateJavascript(shimJs, null)
        view.evaluateJavascript(swJs, null)
        view.evaluateJavascript(mainJs, null)
        view.evaluateJavascript(injectCssJs, null)
        view.evaluateJavascript(contentJs, null)
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) {
                    webView.webChromeClient?.onHideCustomView()
                } else if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    inner class AndroidGifBridge {

        @JavascriptInterface
        fun storageGet(key: String): String {
            val result = JSONObject()
            if (key.isEmpty()) return result.toString()
            val raw = prefs.getString("ext_storage_$key", null) ?: return result.toString()
            return try {
                result.put(key, JSONObject(raw).get("value"))
                result.toString()
            } catch (e: Exception) {
                result.toString()
            }
        }

        @JavascriptInterface
        fun storageSet(itemsJson: String) {
            try {
                val obj = JSONObject(itemsJson)
                val editor = prefs.edit()
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val wrapper = JSONObject().put("value", obj.get(k))
                    editor.putString("ext_storage_$k", wrapper.toString())
                }
                editor.apply()
            } catch (e: Exception) {
                // Ignore malformed JSON
            }
        }

        @JavascriptInterface
        fun storageRemove(key: String) {
            prefs.edit().remove("ext_storage_$key").apply()
        }

        @JavascriptInterface
        fun nativeFetchAsync(reqId: String, targetUrl: String) {
            networkExecutor.execute {
                var conn: HttpURLConnection? = null
                try {
                    val parsed = Uri.parse(targetUrl)
                    val host = parsed.host?.lowercase() ?: ""
                    if (!host.endsWith("tenor.com") && !host.endsWith("googleapis.com") && !host.endsWith("github.com")) {
                        deliverFetchResult(reqId, false, 403, targetUrl, "", "Host tidak diizinkan")
                        return@execute
                    }
                    val url = URL(targetUrl)
                    conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 10000
                        readTimeout = 10000
                        instanceFollowRedirects = true
                        setRequestProperty("User-Agent", desktopUserAgent)
                        if (host.contains("github.com")) {
                            setRequestProperty("Accept", "application/vnd.github+json")
                        }
                    }
                    val status = conn.responseCode
                    val ok = status in 200..299
                    val finalUrl = conn.url?.toString() ?: targetUrl
                    val stream = if (ok) conn.inputStream else conn.errorStream
                    val body = stream?.let {
                        BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { r -> r.readText() }
                    } ?: ""
                    deliverFetchResult(reqId, ok, status, finalUrl, body, null)
                } catch (e: Exception) {
                    deliverFetchResult(reqId, false, 0, targetUrl, "", e.message ?: "Network error")
                } finally {
                    conn?.disconnect()
                }
            }
        }

        private fun deliverFetchResult(
            reqId: String,
            ok: Boolean,
            status: Int,
            finalUrl: String,
            bodyText: String,
            errorMsg: String?
        ) {
            val reqQuoted = JSONObject.quote(reqId)
            val urlQuoted = JSONObject.quote(finalUrl)
            val bodyQuoted = JSONObject.quote(bodyText)
            val errQuoted = if (errorMsg != null) JSONObject.quote(errorMsg) else "null"
            val js = "window.__gcfyOnNativeFetchResult && window.__gcfyOnNativeFetchResult($reqQuoted, $ok, $status, $urlQuoted, $bodyQuoted, $errQuoted);"
            runOnUiThread {
                webView.evaluateJavascript(js, null)
            }
        }
    }
}
